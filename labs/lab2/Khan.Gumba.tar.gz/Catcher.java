// import java.io.*;
// import java.net.*;
// import java.util.concurrent.ConcurrentHashMap;
// import java.util.concurrent.LinkedBlockingQueue;

// /* Catcher class
//  * Continually poles for server messages and adds to sorted client array
//  *
//  */
// public class Catcher extends Thread {
//     Array clientEvents;

//     // Continually check for any packet messages and add it to the client events.
//     public void run(){
// 	String new_event = null;
// 	int seqNum = 0;

// 	while(true){ //???
// 	    MazePacket messageFromServer = null;
// 	    in.(messageFromServer);

// 	    clientEvents[messageFromServer.seqNum] = clientEvents.message;
// 	}

//     }

// }

