ece419 - Lab 2
======

Starting up
- Run "Make"
- Start the server
  - On terminal, run "java MazewarServer ####", where #### represents the port the server shall be listening into (ex. 8000)
- Start Client1 using same files
  - On a seperate terminal, run "java Mazewar"
    - Enter username
    - Enter host location (ex. ug224.eecg.utoronto.ca)
    - Enter port server is listening into (ex. 8000)
  - WAIT for Client 2. Don't move!
- Start Client2 using same files
  - On a seperate terminal, run "java Mazewar"
  - Repeat steps as Client1 setup
- Have fun!

Assumptions
- There is no dynamic entry. Both clients wait for each other until starting the game.


Submitted by:
Kevin Justin Gumba 997585117
Tahia Khan 998897216

Submission date: January 22, 2014
